create function random_past(years integer) returns timestamp without time zone
    language plpgsql
as
$$
begin
        return to_timestamp(extract(epoch from (now() - to_timestamp(random()*86400*365*years))));
    end
$$;

alter function random_past(integer) owner to s264429;

