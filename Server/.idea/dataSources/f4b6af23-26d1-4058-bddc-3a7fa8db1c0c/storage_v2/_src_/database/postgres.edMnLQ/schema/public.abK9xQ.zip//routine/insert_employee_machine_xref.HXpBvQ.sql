create function insert_employee_machine_xref() returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    machine_id integer := 0;
    employee_id integer := 0;
    employees_count integer := 0;
    machines_count integer := 0;
begin
    select count(*) from factory_employee into employees_count;
    select count(*) from circuit_board_machine into machines_count;

    for i in 1..employees_count loop
        select id from circuit_board_machine where state != 'decommissioned' order by random() limit 1 into machine_id;
        insert into employee_machine_xref values (i, machine_id) on conflict do nothing;
    end loop;

    for i in 1..machines_count loop
        select id from factory_employee order by random() limit 1 into employee_id;
        insert into employee_machine_xref values (employee_id, i) on conflict do nothing;
    end loop;

    delete from employee_machine_xref as emx where exists(
        select id from circuit_board_machine where state = 'decommissioned' and id = emx.machine_id
    );
end;
$$;

alter function insert_employee_machine_xref() owner to s264429;

