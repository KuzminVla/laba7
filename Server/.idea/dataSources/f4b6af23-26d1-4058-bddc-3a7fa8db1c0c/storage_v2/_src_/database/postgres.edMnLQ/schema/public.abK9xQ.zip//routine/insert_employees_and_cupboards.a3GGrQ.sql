create function insert_employees_and_cupboards(fnames character varying[], mnames character varying[], lnames character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    j integer := 0;
    k integer := 0;
    count integer := 0;
begin
    for i in 1..array_length(fnames, 1) loop
        for j in 1..array_length(mnames, 1) loop
                for k in 1..array_length(lnames, 1) loop
                        count:= count + 1;
                        insert into factory_employee(fname, mname, lname) values (fnames[i], mnames[j], lnames[k]);
                        insert into tea_cupboard(owner_id, color, capacity) values (count, floor(random() * (16777215 - 0) + 0)::int, floor(random() * (40 - 10) + 10)::int);
                end loop;
        end loop;
    end loop;
end;
$$;

alter function insert_employees_and_cupboards(character varying[], character varying[], character varying[]) owner to s264429;

