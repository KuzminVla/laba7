create function insert_delivery_truck(trucks_count integer) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    random_capacity integer := 0;
begin
    for i in 1..trucks_count loop
       random_capacity := (random() * (150 - 10) + 10)::integer;
       insert into delivery_truck(order_id, capacity, delivery_by)
       values (NULL, random_capacity, NULL);
    end loop;

end
$$;

alter function insert_delivery_truck(integer) owner to s264429;

