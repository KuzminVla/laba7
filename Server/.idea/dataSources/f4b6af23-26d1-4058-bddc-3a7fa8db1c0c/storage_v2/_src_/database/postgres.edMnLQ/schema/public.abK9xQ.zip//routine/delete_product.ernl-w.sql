create function delete_product() returns trigger
    language plpgsql
as
$$
begin
    delete from product where id = old.super_id;
    return old;
end;
$$;

alter function delete_product() owner to s264429;

